package com.ecommerce.coupon.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Data;

import java.util.List;

public class CouponDTOs {

    // ─────────────────── Request DTOs ───────────────────

    @Data
    public static class ApplyCouponRequest {
        @NotNull(message = "Order ID is required")
        @Positive(message = "Order ID must be positive")
        private Long orderId;

        @NotNull(message = "User ID is required")
        @Positive(message = "User ID must be positive")
        private Long userId;

        @NotBlank(message = "Coupon code is required")
        private String couponCode;

        // Optional idempotency key for safe retries
        private String idempotencyKey;
    }

    @Data
    public static class ApplyMultipleCouponsRequest {
        @NotNull(message = "Order ID is required")
        @Positive(message = "Order ID must be positive")
        private Long orderId;

        @NotNull(message = "User ID is required")
        @Positive(message = "User ID must be positive")
        private Long userId;

        @NotNull(message = "Coupon codes list is required")
        private List<String> couponCodes;

        private String idempotencyKey;
    }

    @Data
    public static class CreateCouponRequest {
        @NotBlank(message = "Coupon code is required")
        private String code;

        @NotBlank(message = "Coupon type is required")
        private String type;

        @NotNull(message = "Discount value is required")
        private java.math.BigDecimal discountValue;

        @NotNull(message = "Expiry date is required")
        private java.time.LocalDate expiryDate;

        @NotNull(message = "Usage limit is required")
        private Integer usageLimit;

        private java.math.BigDecimal minOrderValue;
        private String applicableCategory;
    }

    // ─────────────────── Response DTOs ───────────────────

    @Data
    public static class CouponResponse {
        private Long id;
        private String code;
        private String type;
        private java.math.BigDecimal discountValue;
        private java.time.LocalDate expiryDate;
        private Integer usageLimit;
        private Integer currentUsage;
        private java.math.BigDecimal minOrderValue;
        private String applicableCategory;
        private Boolean active;
        private Boolean expired;
    }

    @Data
    public static class ApplyCouponResponse {
        private Long orderId;
        private java.math.BigDecimal originalAmount;
        private java.math.BigDecimal discountApplied;
        private java.math.BigDecimal finalAmount;
        private String couponCode;
        private String message;
        private boolean alreadyApplied;
    }

    @Data
    public static class ApplyMultipleCouponsResponse {
        private Long orderId;
        private java.math.BigDecimal originalAmount;
        private java.math.BigDecimal totalDiscountApplied;
        private java.math.BigDecimal finalAmount;
        private List<String> appliedCoupons;
        private List<String> failedCoupons;
        private String message;
    }

    @Data
    public static class OrderSummaryResponse {
        private Long orderId;
        private Long userId;
        private java.math.BigDecimal totalAmount;
        private java.math.BigDecimal finalAmount;
        private java.math.BigDecimal totalDiscount;
        private String status;
        private List<DiscountDetail> discounts;

        @Data
        public static class DiscountDetail {
            private String couponCode;
            private String discountType;
            private java.math.BigDecimal discountAmount;
            private java.time.LocalDateTime appliedAt;
        }
    }

    @Data
    public static class ApiResponse<T> {
        private boolean success;
        private String message;
        private T data;

        public static <T> ApiResponse<T> success(T data, String message) {
            ApiResponse<T> response = new ApiResponse<>();
            response.setSuccess(true);
            response.setMessage(message);
            response.setData(data);
            return response;
        }

        public static <T> ApiResponse<T> error(String message) {
            ApiResponse<T> response = new ApiResponse<>();
            response.setSuccess(false);
            response.setMessage(message);
            return response;
        }
    }
}
