package com.ecommerce.coupon.service.strategy;

import com.ecommerce.coupon.entity.Coupon;
import com.ecommerce.coupon.entity.Order;

import java.math.BigDecimal;

/**
 * Strategy Pattern interface for discount calculation.
 * Each coupon type implements its own discount logic.
 */
public interface DiscountStrategy {

    /**
     * Calculate the discount amount for the given coupon and order.
     *
     * @param coupon the coupon being applied
     * @param order  the order to which the coupon is applied
     * @return the calculated discount amount (never negative, never exceeds order total)
     */
    BigDecimal calculateDiscount(Coupon coupon, Order order);

    /**
     * Returns the CouponType this strategy handles.
     */
    String getSupportedType();
}
