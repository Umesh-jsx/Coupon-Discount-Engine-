package com.ecommerce.coupon.repository;

import com.ecommerce.coupon.entity.UserCoupon;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserCouponRepository extends JpaRepository<UserCoupon, Long> {

    /**
     * Check if a user has already used a specific coupon.
     * Used to enforce single-use coupons per user.
     */
    @Query("SELECT uc FROM UserCoupon uc WHERE uc.user.id = :userId AND uc.coupon.id = :couponId")
    Optional<UserCoupon> findByUserIdAndCouponId(@Param("userId") Long userId,
                                                  @Param("couponId") Long couponId);

    boolean existsByIdempotencyKey(String idempotencyKey);
}
