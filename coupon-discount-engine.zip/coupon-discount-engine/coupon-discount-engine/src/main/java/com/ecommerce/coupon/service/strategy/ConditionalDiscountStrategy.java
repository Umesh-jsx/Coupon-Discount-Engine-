package com.ecommerce.coupon.service.strategy;

import com.ecommerce.coupon.entity.Coupon;
import com.ecommerce.coupon.entity.Order;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * Conditional discount: applies a flat discount only when the order total
 * meets or exceeds the coupon's minOrderValue threshold.
 * Example: BOGO100 → Rs.100 off when order >= Rs.1000.
 * If threshold not met at strategy level, returns zero (validation done upstream).
 */
@Component
public class ConditionalDiscountStrategy implements DiscountStrategy {

    private static final BigDecimal BONUS_MULTIPLIER = new BigDecimal("0.05");

    @Override
    public BigDecimal calculateDiscount(Coupon coupon, Order order) {
        BigDecimal threshold = coupon.getMinOrderValue();
        BigDecimal orderTotal = order.getTotalAmount();

        if (threshold != null && orderTotal.compareTo(threshold) >= 0) {
            // Base flat discount
            BigDecimal baseDiscount = coupon.getDiscountValue();

            // Bonus: 5% extra for every Rs.500 above threshold (tiered reward)
            BigDecimal excess = orderTotal.subtract(threshold);
            BigDecimal bonusTiers = excess.divide(new BigDecimal("500"), 0, RoundingMode.FLOOR);
            BigDecimal bonusDiscount = baseDiscount.multiply(BONUS_MULTIPLIER).multiply(bonusTiers);

            BigDecimal totalDiscount = baseDiscount.add(bonusDiscount);

            // Cap at order total
            if (totalDiscount.compareTo(orderTotal) > 0) {
                return orderTotal;
            }
            return totalDiscount.setScale(2, RoundingMode.HALF_UP);
        }

        return BigDecimal.ZERO;
    }

    @Override
    public String getSupportedType() {
        return "CONDITIONAL";
    }
}
