package com.ecommerce.coupon.exception;

public class CouponException extends RuntimeException {
    public CouponException(String message) {
        super(message);
    }
}
