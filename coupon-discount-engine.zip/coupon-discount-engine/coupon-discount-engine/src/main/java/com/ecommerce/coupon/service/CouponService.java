package com.ecommerce.coupon.service;

import com.ecommerce.coupon.dto.CouponDTOs.*;
import com.ecommerce.coupon.entity.*;
import com.ecommerce.coupon.exception.CouponAlreadyUsedException;
import com.ecommerce.coupon.exception.CouponException;
import com.ecommerce.coupon.exception.ResourceNotFoundException;
import com.ecommerce.coupon.repository.*;
import com.ecommerce.coupon.service.strategy.DiscountStrategy;
import com.ecommerce.coupon.service.strategy.DiscountStrategyFactory;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
public class CouponService {

    private final CouponRepository couponRepository;
    private final UserRepository userRepository;
    private final OrderRepository orderRepository;
    private final UserCouponRepository userCouponRepository;
    private final OrderDiscountRepository orderDiscountRepository;
    private final DiscountStrategyFactory strategyFactory;

    // ─────────────────── Coupon CRUD ───────────────────

    @Transactional
    public CouponResponse createCoupon(CreateCouponRequest request) {
        if (couponRepository.existsByCode(request.getCode())) {
            throw new CouponException("Coupon code already exists: " + request.getCode());
        }

        Coupon coupon = new Coupon();
        coupon.setCode(request.getCode().toUpperCase());
        coupon.setType(CouponType.valueOf(request.getType()));
        coupon.setDiscountValue(request.getDiscountValue());
        coupon.setExpiryDate(request.getExpiryDate());
        coupon.setUsageLimit(request.getUsageLimit());
        coupon.setMinOrderValue(request.getMinOrderValue() != null
                ? request.getMinOrderValue() : BigDecimal.ZERO);
        coupon.setApplicableCategory(request.getApplicableCategory());

        Coupon saved = couponRepository.save(coupon);
        log.info("Coupon created: {}", saved.getCode());
        return mapToCouponResponse(saved);
    }

    @Transactional(readOnly = true)
    public List<CouponResponse> getAllCoupons() {
        return couponRepository.findAll().stream()
                .map(this::mapToCouponResponse)
                .toList();
    }

    @Transactional(readOnly = true)
    public CouponResponse getCouponByCode(String code) {
        Coupon coupon = couponRepository.findByCode(code.toUpperCase())
                .orElseThrow(() -> new ResourceNotFoundException("Coupon not found: " + code));
        return mapToCouponResponse(coupon);
    }

    // ─────────────────── Apply Single Coupon ───────────────────

    /**
     * Applies a single coupon to an order.
     * Idempotent: if the same idempotencyKey is supplied again, returns
     * the existing result without re-applying.
     * Concurrency-safe: uses PESSIMISTIC_WRITE lock on coupon row.
     */
    @Transactional
    public ApplyCouponResponse applyCoupon(ApplyCouponRequest request) {
        String idempotencyKey = buildIdempotencyKey(
                request.getIdempotencyKey(), request.getOrderId(),
                request.getCouponCode(), request.getUserId());

        // ── Idempotency check ──
        return orderDiscountRepository.findByIdempotencyKey(idempotencyKey)
                .map(existing -> buildAlreadyAppliedResponse(existing))
                .orElseGet(() -> doApplyCoupon(
                        request.getOrderId(),
                        request.getUserId(),
                        request.getCouponCode(),
                        idempotencyKey));
    }

    private ApplyCouponResponse doApplyCoupon(Long orderId, Long userId,
                                               String couponCode, String idempotencyKey) {
        AppUser user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + userId));

        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found: " + orderId));

        if (!order.getUser().getId().equals(userId)) {
            throw new CouponException("Order does not belong to user");
        }

        // Lock the coupon row to prevent concurrent updates
        Coupon coupon = couponRepository.findByCodeWithLock(couponCode.toUpperCase())
                .orElseThrow(() -> new ResourceNotFoundException("Coupon not found: " + couponCode));

        // ── Validation ──
        validateCoupon(coupon, order, user);

        // ── Calculate discount via Strategy Pattern ──
        DiscountStrategy strategy = strategyFactory.getStrategy(coupon.getType().name());
        BigDecimal discountAmount = strategy.calculateDiscount(coupon, order);

        // ── Persist ──
        BigDecimal finalAmount = persistDiscount(order, coupon, user, discountAmount, idempotencyKey);

        ApplyCouponResponse response = new ApplyCouponResponse();
        response.setOrderId(orderId);
        response.setOriginalAmount(order.getTotalAmount());
        response.setDiscountApplied(discountAmount);
        response.setFinalAmount(finalAmount);
        response.setCouponCode(coupon.getCode());
        response.setMessage("Coupon applied successfully");
        response.setAlreadyApplied(false);
        return response;
    }

    // ─────────────────── Apply Multiple Coupons ───────────────────

    /**
     * Applies multiple coupons sequentially to an order.
     * Each coupon is applied on the running finalAmount.
     * Partial failures are collected; successful ones are committed.
     */
    @Transactional
    public ApplyMultipleCouponsResponse applyMultipleCoupons(ApplyMultipleCouponsRequest request) {
        AppUser user = userRepository.findById(request.getUserId())
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + request.getUserId()));

        Order order = orderRepository.findById(request.getOrderId())
                .orElseThrow(() -> new ResourceNotFoundException("Order not found: " + request.getOrderId()));

        if (!order.getUser().getId().equals(request.getUserId())) {
            throw new CouponException("Order does not belong to user");
        }

        List<String> applied = new ArrayList<>();
        List<String> failed = new ArrayList<>();
        BigDecimal totalDiscount = BigDecimal.ZERO;

        for (String couponCode : request.getCouponCodes()) {
            try {
                String key = buildIdempotencyKey(request.getIdempotencyKey(),
                        request.getOrderId(), couponCode, request.getUserId());

                // Check idempotency
                if (orderDiscountRepository.findByIdempotencyKey(key).isPresent()) {
                    applied.add(couponCode + " (already applied)");
                    continue;
                }

                Coupon coupon = couponRepository.findByCodeWithLock(couponCode.toUpperCase())
                        .orElseThrow(() -> new ResourceNotFoundException("Coupon not found: " + couponCode));

                validateCoupon(coupon, order, user);

                DiscountStrategy strategy = strategyFactory.getStrategy(coupon.getType().name());
                BigDecimal discount = strategy.calculateDiscount(coupon, order);

                persistDiscount(order, coupon, user, discount, key);
                totalDiscount = totalDiscount.add(discount);
                applied.add(couponCode);

                // Reload order to get updated finalAmount for next iteration
                order = orderRepository.findById(request.getOrderId()).orElse(order);

            } catch (Exception ex) {
                log.warn("Failed to apply coupon {}: {}", couponCode, ex.getMessage());
                failed.add(couponCode + " (" + ex.getMessage() + ")");
            }
        }

        ApplyMultipleCouponsResponse response = new ApplyMultipleCouponsResponse();
        response.setOrderId(request.getOrderId());
        response.setOriginalAmount(order.getTotalAmount());
        response.setTotalDiscountApplied(totalDiscount);
        response.setFinalAmount(order.getFinalAmount() != null
                ? order.getFinalAmount() : order.getTotalAmount().subtract(totalDiscount));
        response.setAppliedCoupons(applied);
        response.setFailedCoupons(failed);
        response.setMessage(applied.isEmpty() ? "No coupons applied" :
                applied.size() + " coupon(s) applied successfully");
        return response;
    }

    // ─────────────────── Order Summary ───────────────────

    @Transactional(readOnly = true)
    public OrderSummaryResponse getOrderSummary(Long orderId) {
        Order order = orderRepository.findByIdWithDiscounts(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found: " + orderId));

        OrderSummaryResponse response = new OrderSummaryResponse();
        response.setOrderId(order.getId());
        response.setUserId(order.getUser().getId());
        response.setTotalAmount(order.getTotalAmount());
        response.setFinalAmount(order.getFinalAmount() != null
                ? order.getFinalAmount() : order.getTotalAmount());
        response.setStatus(order.getStatus());

        BigDecimal totalDiscount = BigDecimal.ZERO;
        List<OrderSummaryResponse.DiscountDetail> details = new ArrayList<>();

        for (OrderDiscount od : order.getOrderDiscounts()) {
            totalDiscount = totalDiscount.add(od.getDiscountApplied());

            OrderSummaryResponse.DiscountDetail detail = new OrderSummaryResponse.DiscountDetail();
            detail.setCouponCode(od.getCoupon().getCode());
            detail.setDiscountType(od.getCoupon().getType().name());
            detail.setDiscountAmount(od.getDiscountApplied());
            detail.setAppliedAt(od.getAppliedAt());
            details.add(detail);
        }

        response.setTotalDiscount(totalDiscount);
        response.setDiscounts(details);
        return response;
    }

    // ─────────────────── Validation ───────────────────

    private void validateCoupon(Coupon coupon, Order order, AppUser user) {
        if (!coupon.getActive()) {
            throw new CouponException("Coupon is inactive: " + coupon.getCode());
        }

        if (coupon.isExpired()) {
            throw new CouponException("Coupon has expired: " + coupon.getCode());
        }

        if (coupon.isUsageLimitReached()) {
            throw new CouponException("Coupon usage limit reached: " + coupon.getCode());
        }

        // Min order value check
        if (order.getTotalAmount().compareTo(coupon.getMinOrderValue()) < 0) {
            throw new CouponException(
                    "Order total " + order.getTotalAmount() +
                    " does not meet minimum order value " + coupon.getMinOrderValue() +
                    " for coupon: " + coupon.getCode());
        }

        // Category restriction check
        if (coupon.getApplicableCategory() != null && !coupon.getApplicableCategory().isBlank()) {
            if (order.getCategory() == null ||
                !order.getCategory().equalsIgnoreCase(coupon.getApplicableCategory())) {
                throw new CouponException(
                        "Coupon " + coupon.getCode() +
                        " is only valid for category: " + coupon.getApplicableCategory());
            }
        }

        // Already applied to this order?
        orderDiscountRepository.findByOrderIdAndCouponId(order.getId(), coupon.getId())
                .ifPresent(od -> {
                    throw new CouponAlreadyUsedException(
                            "Coupon " + coupon.getCode() + " is already applied to this order");
                });

        // Single-use per user check
        userCouponRepository.findByUserIdAndCouponId(user.getId(), coupon.getId())
                .ifPresent(uc -> {
                    if (Boolean.TRUE.equals(uc.getUsedFlag())) {
                        throw new CouponAlreadyUsedException(
                                "User has already used coupon: " + coupon.getCode());
                    }
                });
    }

    // ─────────────────── Persist Discount ───────────────────

    private BigDecimal persistDiscount(Order order, Coupon coupon, AppUser user,
                                       BigDecimal discountAmount, String idempotencyKey) {
        // 1. Increment coupon usage (optimistic lock via @Version)
        coupon.setCurrentUsage(coupon.getCurrentUsage() + 1);
        couponRepository.save(coupon);

        // 2. Mark user coupon as used
        UserCoupon userCoupon = userCouponRepository
                .findByUserIdAndCouponId(user.getId(), coupon.getId())
                .orElse(new UserCoupon());
        userCoupon.setUser(user);
        userCoupon.setCoupon(coupon);
        userCoupon.setUsedFlag(true);
        userCoupon.setUsedAt(LocalDateTime.now());
        userCoupon.setIdempotencyKey(idempotencyKey + "_uc");
        userCouponRepository.save(userCoupon);

        // 3. Record OrderDiscount
        OrderDiscount orderDiscount = new OrderDiscount();
        orderDiscount.setOrder(order);
        orderDiscount.setCoupon(coupon);
        orderDiscount.setDiscountApplied(discountAmount);
        orderDiscount.setAppliedAt(LocalDateTime.now());
        orderDiscount.setIdempotencyKey(idempotencyKey);
        orderDiscountRepository.save(orderDiscount);

        // 4. Update order final amount
        BigDecimal currentFinal = order.getFinalAmount() != null
                ? order.getFinalAmount() : order.getTotalAmount();
        BigDecimal newFinal = currentFinal.subtract(discountAmount);
        if (newFinal.compareTo(BigDecimal.ZERO) < 0) {
            newFinal = BigDecimal.ZERO;
        }
        order.setFinalAmount(newFinal);
        orderRepository.save(order);

        log.info("Discount applied: coupon={}, order={}, discount={}, finalAmount={}",
                coupon.getCode(), order.getId(), discountAmount, newFinal);

        return newFinal;
    }

    // ─────────────────── Helpers ───────────────────

    private String buildIdempotencyKey(String clientKey, Long orderId,
                                        String couponCode, Long userId) {
        if (clientKey != null && !clientKey.isBlank()) {
            return clientKey + "_" + couponCode.toUpperCase();
        }
        return "order-" + orderId + "_user-" + userId + "_coupon-" + couponCode.toUpperCase();
    }

    private ApplyCouponResponse buildAlreadyAppliedResponse(OrderDiscount existing) {
        ApplyCouponResponse response = new ApplyCouponResponse();
        response.setOrderId(existing.getOrder().getId());
        response.setDiscountApplied(existing.getDiscountApplied());
        response.setCouponCode(existing.getCoupon().getCode());
        response.setMessage("Coupon was already applied (idempotent response)");
        response.setAlreadyApplied(true);
        return response;
    }

    private CouponResponse mapToCouponResponse(Coupon coupon) {
        CouponResponse response = new CouponResponse();
        response.setId(coupon.getId());
        response.setCode(coupon.getCode());
        response.setType(coupon.getType().name());
        response.setDiscountValue(coupon.getDiscountValue());
        response.setExpiryDate(coupon.getExpiryDate());
        response.setUsageLimit(coupon.getUsageLimit());
        response.setCurrentUsage(coupon.getCurrentUsage());
        response.setMinOrderValue(coupon.getMinOrderValue());
        response.setApplicableCategory(coupon.getApplicableCategory());
        response.setActive(coupon.getActive());
        response.setExpired(coupon.isExpired());
        return response;
    }
}
