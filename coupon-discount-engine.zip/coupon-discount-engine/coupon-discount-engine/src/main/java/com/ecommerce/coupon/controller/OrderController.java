package com.ecommerce.coupon.controller;

import com.ecommerce.coupon.entity.AppUser;
import com.ecommerce.coupon.entity.Order;
import com.ecommerce.coupon.exception.ResourceNotFoundException;
import com.ecommerce.coupon.repository.OrderRepository;
import com.ecommerce.coupon.repository.UserRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/orders")
@RequiredArgsConstructor
@Tag(name = "Order Management", description = "Create and view orders")
public class OrderController {

    private final OrderRepository orderRepository;
    private final UserRepository userRepository;

    @Data
    static class CreateOrderRequest {
        @NotNull private Long userId;
        @NotNull @Positive private BigDecimal totalAmount;
        private String category;
    }

    @PostMapping
    @Transactional
    @Operation(summary = "Create a new order")
    public ResponseEntity<Map<String, Object>> createOrder(
            @Valid @RequestBody CreateOrderRequest request) {
        AppUser user = userRepository.findById(request.getUserId())
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + request.getUserId()));

        Order order = new Order();
        order.setUser(user);
        order.setTotalAmount(request.getTotalAmount());
        order.setFinalAmount(request.getTotalAmount());
        order.setCategory(request.getCategory() != null ? request.getCategory().toUpperCase() : "GENERAL");
        order.setStatus("PENDING");
        Order saved = orderRepository.save(order);

        return ResponseEntity.status(HttpStatus.CREATED).body(Map.of(
                "orderId", saved.getId(),
                "userId", user.getId(),
                "totalAmount", saved.getTotalAmount(),
                "category", saved.getCategory(),
                "status", saved.getStatus()
        ));
    }

    @GetMapping("/{orderId}")
    @Transactional(readOnly = true)
    @Operation(summary = "Get order by ID")
    public ResponseEntity<Map<String, Object>> getOrder(@PathVariable Long orderId) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found: " + orderId));
        return ResponseEntity.ok(Map.of(
                "orderId", order.getId(),
                "totalAmount", order.getTotalAmount(),
                "finalAmount", order.getFinalAmount() != null ? order.getFinalAmount() : order.getTotalAmount(),
                "category", order.getCategory() != null ? order.getCategory() : "GENERAL",
                "status", order.getStatus()
        ));
    }

    @GetMapping
    @Transactional(readOnly = true)
    @Operation(summary = "List all orders")
    public ResponseEntity<List<Map<String, Object>>> getAllOrders() {
        List<Map<String, Object>> orders = orderRepository.findAll().stream()
                .map(o -> Map.<String, Object>of(
                        "orderId", o.getId(),
                        "userId", o.getUser().getId(),
                        "totalAmount", o.getTotalAmount(),
                        "finalAmount", o.getFinalAmount() != null ? o.getFinalAmount() : o.getTotalAmount(),
                        "category", o.getCategory() != null ? o.getCategory() : "GENERAL",
                        "status", o.getStatus()
                ))
                .toList();
        return ResponseEntity.ok(orders);
    }
}
