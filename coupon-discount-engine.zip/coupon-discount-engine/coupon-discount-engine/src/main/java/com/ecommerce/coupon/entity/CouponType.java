package com.ecommerce.coupon.entity;

public enum CouponType {
    FLAT,
    PERCENTAGE,
    CONDITIONAL
}
