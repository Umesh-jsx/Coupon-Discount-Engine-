package com.ecommerce.coupon.repository;

import com.ecommerce.coupon.entity.OrderDiscount;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface OrderDiscountRepository extends JpaRepository<OrderDiscount, Long> {

    /**
     * Check if a coupon was already applied to a specific order.
     * Used to prevent duplicate coupon application (idempotency check).
     */
    @Query("SELECT od FROM OrderDiscount od WHERE od.order.id = :orderId AND od.coupon.id = :couponId")
    Optional<OrderDiscount> findByOrderIdAndCouponId(@Param("orderId") Long orderId,
                                                      @Param("couponId") Long couponId);

    Optional<OrderDiscount> findByIdempotencyKey(String idempotencyKey);
}
