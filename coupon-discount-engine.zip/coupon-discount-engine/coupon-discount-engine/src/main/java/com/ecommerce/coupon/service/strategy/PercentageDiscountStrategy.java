package com.ecommerce.coupon.service.strategy;

import com.ecommerce.coupon.entity.Coupon;
import com.ecommerce.coupon.entity.Order;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * Percentage discount: calculates a percentage off the order total.
 * Example: SAVE10PCT → 10% off the order total.
 * Maximum discount capped at 90% to prevent full order waivers.
 */
@Component
public class PercentageDiscountStrategy implements DiscountStrategy {

    private static final BigDecimal MAX_PERCENTAGE = new BigDecimal("90");
    private static final BigDecimal HUNDRED = new BigDecimal("100");

    @Override
    public BigDecimal calculateDiscount(Coupon coupon, Order order) {
        BigDecimal percentage = coupon.getDiscountValue();

        // Cap percentage at 90%
        if (percentage.compareTo(MAX_PERCENTAGE) > 0) {
            percentage = MAX_PERCENTAGE;
        }

        return order.getTotalAmount()
                .multiply(percentage)
                .divide(HUNDRED, 2, RoundingMode.HALF_UP);
    }

    @Override
    public String getSupportedType() {
        return "PERCENTAGE";
    }
}
