package com.ecommerce.coupon.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "coupon")
@Getter
@Setter
@ToString(exclude = {"userCoupons", "orderDiscounts"})
public class Coupon {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Coupon code cannot be blank")
    @Size(min = 3, max = 30, message = "Coupon code must be between 3 and 30 characters")
    @Column(name = "code", unique = true, nullable = false)
    private String code;

    @NotNull(message = "Coupon type is required")
    @Enumerated(EnumType.STRING)
    @Column(name = "type", nullable = false)
    private CouponType type;

    @NotNull(message = "Discount value is required")
    @DecimalMin(value = "0.01", message = "Discount value must be greater than 0")
    @Column(name = "discount_value", nullable = false, precision = 10, scale = 2)
    private BigDecimal discountValue;

    @NotNull(message = "Expiry date is required")
    @Column(name = "expiry_date", nullable = false)
    private LocalDate expiryDate;

    @Min(value = 1, message = "Usage limit must be at least 1")
    @Column(name = "usage_limit", nullable = false)
    private Integer usageLimit;

    @Column(name = "current_usage", nullable = false)
    private Integer currentUsage = 0;

    @Column(name = "min_order_value", precision = 10, scale = 2)
    private BigDecimal minOrderValue = BigDecimal.ZERO;

    // null means applicable to all categories
    @Column(name = "applicable_category")
    private String applicableCategory;

    @Column(name = "active", nullable = false)
    private Boolean active = true;

    @Version
    @Column(name = "version")
    private Long version;

    @OneToMany(mappedBy = "coupon", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<UserCoupon> userCoupons = new ArrayList<>();

    @OneToMany(mappedBy = "coupon", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<OrderDiscount> orderDiscounts = new ArrayList<>();

    public boolean isExpired() {
        return LocalDate.now().isAfter(expiryDate);
    }

    public boolean isUsageLimitReached() {
        return currentUsage >= usageLimit;
    }

    public boolean isSingleUse() {
        return usageLimit == 1;
    }
}
