package com.ecommerce.coupon.service.strategy;

import com.ecommerce.coupon.exception.CouponException;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Factory that resolves the correct DiscountStrategy at runtime.
 * All strategies are auto-injected via Spring; adding a new strategy
 * requires only implementing DiscountStrategy and annotating with @Component.
 */
@Component
public class DiscountStrategyFactory {

    private final Map<String, DiscountStrategy> strategyMap;

    public DiscountStrategyFactory(List<DiscountStrategy> strategies) {
        this.strategyMap = strategies.stream()
                .collect(Collectors.toMap(DiscountStrategy::getSupportedType, Function.identity()));
    }

    public DiscountStrategy getStrategy(String couponType) {
        DiscountStrategy strategy = strategyMap.get(couponType);
        if (strategy == null) {
            throw new CouponException("No discount strategy found for coupon type: " + couponType);
        }
        return strategy;
    }
}
