package com.ecommerce.coupon.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig {

    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("Coupon & Discount Engine API")
                        .version("1.0.0")
                        .description("""
                                Enterprise Coupon & Discount Engine
                                
                                Features:
                                - Apply single and multiple coupons to orders
                                - Strategy Pattern for FLAT, PERCENTAGE, CONDITIONAL discounts
                                - Idempotent coupon application (safe retries)
                                - Pessimistic locking to prevent concurrent reuse
                                - N+1 prevention via fetch joins
                                - Hibernate Validator for input validation
                                """)
                        .contact(new Contact()
                                .name("E-Commerce Backend Team")
                                .email("backend@ecommerce.com")));
    }
}
