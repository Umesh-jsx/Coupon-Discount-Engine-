package com.ecommerce.coupon.controller;

import com.ecommerce.coupon.entity.AppUser;
import com.ecommerce.coupon.exception.ResourceNotFoundException;
import com.ecommerce.coupon.repository.UserRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
@Tag(name = "User Management", description = "Create and view users")
public class UserController {

    private final UserRepository userRepository;

    @Data
    static class CreateUserRequest {
        @NotBlank private String username;
        @NotBlank @Email private String email;
    }

    @PostMapping
    @Transactional
    @Operation(summary = "Create a new user")
    public ResponseEntity<Map<String, Object>> createUser(
            @Valid @RequestBody CreateUserRequest request) {
        AppUser user = new AppUser();
        user.setUsername(request.getUsername());
        user.setEmail(request.getEmail());
        AppUser saved = userRepository.save(user);
        return ResponseEntity.status(HttpStatus.CREATED).body(Map.of(
                "userId", saved.getId(),
                "username", saved.getUsername(),
                "email", saved.getEmail()
        ));
    }

    @GetMapping
    @Transactional(readOnly = true)
    @Operation(summary = "List all users")
    public ResponseEntity<List<Map<String, Object>>> getAllUsers() {
        List<Map<String, Object>> users = userRepository.findAll().stream()
                .map(u -> Map.<String, Object>of(
                        "userId", u.getId(),
                        "username", u.getUsername(),
                        "email", u.getEmail()
                ))
                .toList();
        return ResponseEntity.ok(users);
    }

    @GetMapping("/{userId}")
    @Transactional(readOnly = true)
    @Operation(summary = "Get user by ID")
    public ResponseEntity<Map<String, Object>> getUser(@PathVariable Long userId) {
        AppUser user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + userId));
        return ResponseEntity.ok(Map.of(
                "userId", user.getId(),
                "username", user.getUsername(),
                "email", user.getEmail()
        ));
    }
}
