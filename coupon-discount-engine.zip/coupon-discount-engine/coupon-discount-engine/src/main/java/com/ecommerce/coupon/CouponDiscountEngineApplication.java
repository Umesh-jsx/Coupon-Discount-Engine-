package com.ecommerce.coupon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CouponDiscountEngineApplication {

    public static void main(String[] args) {
        SpringApplication.run(CouponDiscountEngineApplication.class, args);
    }
}
