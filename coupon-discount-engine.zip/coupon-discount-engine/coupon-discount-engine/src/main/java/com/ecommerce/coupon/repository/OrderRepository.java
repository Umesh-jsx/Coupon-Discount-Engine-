package com.ecommerce.coupon.repository;

import com.ecommerce.coupon.entity.Order;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {

    /**
     * Fetch join prevents N+1 when loading order with its discounts and coupons.
     */
    @Query("SELECT o FROM Order o " +
           "LEFT JOIN FETCH o.orderDiscounts od " +
           "LEFT JOIN FETCH od.coupon " +
           "WHERE o.id = :orderId")
    Optional<Order> findByIdWithDiscounts(@Param("orderId") Long orderId);

    /**
     * Find all orders for a user with discounts eagerly loaded.
     */
    @Query("SELECT DISTINCT o FROM Order o " +
           "LEFT JOIN FETCH o.orderDiscounts od " +
           "LEFT JOIN FETCH od.coupon " +
           "WHERE o.user.id = :userId")
    List<Order> findAllByUserIdWithDiscounts(@Param("userId") Long userId);
}
