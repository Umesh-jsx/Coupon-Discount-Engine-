package com.ecommerce.coupon.service.strategy;

import com.ecommerce.coupon.entity.Coupon;
import com.ecommerce.coupon.entity.Order;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

/**
 * Flat discount: subtracts a fixed rupee/dollar amount from the order total.
 * Example: FLAT50 → Rs.50 off any order above min threshold.
 */
@Component
public class FlatDiscountStrategy implements DiscountStrategy {

    @Override
    public BigDecimal calculateDiscount(Coupon coupon, Order order) {
        BigDecimal discount = coupon.getDiscountValue();
        // Discount cannot exceed the order total
        if (discount.compareTo(order.getTotalAmount()) > 0) {
            return order.getTotalAmount();
        }
        return discount;
    }

    @Override
    public String getSupportedType() {
        return "FLAT";
    }
}
