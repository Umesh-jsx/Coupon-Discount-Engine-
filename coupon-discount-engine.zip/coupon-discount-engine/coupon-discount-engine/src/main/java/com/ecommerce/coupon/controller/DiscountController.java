package com.ecommerce.coupon.controller;

import com.ecommerce.coupon.dto.CouponDTOs.*;
import com.ecommerce.coupon.service.CouponService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/discounts")
@RequiredArgsConstructor
@Tag(name = "Discount Engine", description = "Apply coupons and compute discounts on orders")
public class DiscountController {

    private final CouponService couponService;

    @PostMapping("/apply")
    @Operation(summary = "Apply a single coupon to an order",
               description = "Idempotent: supply idempotencyKey for safe retries. " +
                             "Concurrent requests are serialized via DB-level locking.")
    public ResponseEntity<ApiResponse<ApplyCouponResponse>> applyCoupon(
            @Valid @RequestBody ApplyCouponRequest request) {
        ApplyCouponResponse result = couponService.applyCoupon(request);
        return ResponseEntity.ok(ApiResponse.success(result, result.getMessage()));
    }

    @PostMapping("/apply-multiple")
    @Operation(summary = "Apply multiple coupons to a single order",
               description = "Coupons are applied sequentially. Partial failures do not " +
                             "roll back successfully applied coupons.")
    public ResponseEntity<ApiResponse<ApplyMultipleCouponsResponse>> applyMultipleCoupons(
            @Valid @RequestBody ApplyMultipleCouponsRequest request) {
        ApplyMultipleCouponsResponse result = couponService.applyMultipleCoupons(request);
        return ResponseEntity.ok(ApiResponse.success(result, result.getMessage()));
    }

    @GetMapping("/orders/{orderId}/summary")
    @Operation(summary = "Get discount summary for an order",
               description = "Returns original amount, all applied discounts, and final amount. " +
                             "Uses fetch join to avoid N+1 queries.")
    public ResponseEntity<ApiResponse<OrderSummaryResponse>> getOrderSummary(
            @PathVariable Long orderId) {
        OrderSummaryResponse summary = couponService.getOrderSummary(orderId);
        return ResponseEntity.ok(ApiResponse.success(summary, "Order summary retrieved"));
    }
}
