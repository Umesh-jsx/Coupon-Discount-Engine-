package com.ecommerce.coupon;

import com.ecommerce.coupon.entity.Coupon;
import com.ecommerce.coupon.entity.CouponType;
import com.ecommerce.coupon.entity.Order;
import com.ecommerce.coupon.service.strategy.ConditionalDiscountStrategy;
import com.ecommerce.coupon.service.strategy.FlatDiscountStrategy;
import com.ecommerce.coupon.service.strategy.PercentageDiscountStrategy;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

class DiscountStrategyTest {

    private FlatDiscountStrategy flatStrategy;
    private PercentageDiscountStrategy percentageStrategy;
    private ConditionalDiscountStrategy conditionalStrategy;

    private Order order;
    private Coupon coupon;

    @BeforeEach
    void setUp() {
        flatStrategy = new FlatDiscountStrategy();
        percentageStrategy = new PercentageDiscountStrategy();
        conditionalStrategy = new ConditionalDiscountStrategy();

        order = new Order();
        order.setTotalAmount(new BigDecimal("1000.00"));

        coupon = new Coupon();
        coupon.setExpiryDate(LocalDate.now().plusDays(30));
        coupon.setUsageLimit(100);
        coupon.setCurrentUsage(0);
        coupon.setMinOrderValue(BigDecimal.ZERO);
        coupon.setActive(true);
    }

    @Test
    @DisplayName("Flat discount returns fixed amount")
    void testFlatDiscount() {
        coupon.setType(CouponType.FLAT);
        coupon.setDiscountValue(new BigDecimal("50.00"));
        BigDecimal discount = flatStrategy.calculateDiscount(coupon, order);
        assertEquals(new BigDecimal("50.00"), discount);
    }

    @Test
    @DisplayName("Flat discount capped at order total")
    void testFlatDiscountCappedAtOrderTotal() {
        coupon.setType(CouponType.FLAT);
        coupon.setDiscountValue(new BigDecimal("2000.00")); // more than order
        BigDecimal discount = flatStrategy.calculateDiscount(coupon, order);
        assertEquals(order.getTotalAmount(), discount);
    }

    @Test
    @DisplayName("Percentage discount calculates correctly")
    void testPercentageDiscount() {
        coupon.setType(CouponType.PERCENTAGE);
        coupon.setDiscountValue(new BigDecimal("10.00")); // 10%
        BigDecimal discount = percentageStrategy.calculateDiscount(coupon, order);
        assertEquals(new BigDecimal("100.00"), discount);
    }

    @Test
    @DisplayName("Percentage discount capped at 90%")
    void testPercentageDiscountMaxCap() {
        coupon.setType(CouponType.PERCENTAGE);
        coupon.setDiscountValue(new BigDecimal("95.00")); // over 90%
        BigDecimal discount = percentageStrategy.calculateDiscount(coupon, order);
        assertEquals(new BigDecimal("900.00"), discount); // capped at 90%
    }

    @Test
    @DisplayName("Conditional discount applied when threshold met")
    void testConditionalDiscountAboveThreshold() {
        coupon.setType(CouponType.CONDITIONAL);
        coupon.setDiscountValue(new BigDecimal("100.00"));
        coupon.setMinOrderValue(new BigDecimal("500.00"));
        order.setTotalAmount(new BigDecimal("1000.00"));
        BigDecimal discount = conditionalStrategy.calculateDiscount(coupon, order);
        assertTrue(discount.compareTo(new BigDecimal("100.00")) >= 0);
    }

    @Test
    @DisplayName("Conditional discount returns zero when threshold not met")
    void testConditionalDiscountBelowThreshold() {
        coupon.setType(CouponType.CONDITIONAL);
        coupon.setDiscountValue(new BigDecimal("100.00"));
        coupon.setMinOrderValue(new BigDecimal("2000.00")); // threshold higher than order
        BigDecimal discount = conditionalStrategy.calculateDiscount(coupon, order);
        assertEquals(BigDecimal.ZERO, discount);
    }

    @Test
    @DisplayName("Coupon expiry detection works")
    void testCouponExpiry() {
        coupon.setExpiryDate(LocalDate.now().minusDays(1));
        assertTrue(coupon.isExpired());

        coupon.setExpiryDate(LocalDate.now().plusDays(1));
        assertFalse(coupon.isExpired());
    }

    @Test
    @DisplayName("Usage limit detection works")
    void testUsageLimitReached() {
        coupon.setUsageLimit(5);
        coupon.setCurrentUsage(5);
        assertTrue(coupon.isUsageLimitReached());

        coupon.setCurrentUsage(4);
        assertFalse(coupon.isUsageLimitReached());
    }
}
